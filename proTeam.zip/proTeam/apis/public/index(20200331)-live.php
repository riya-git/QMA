<?php 

declare(strict_types=1);

date_default_timezone_set('Asia/Kolkata');
 
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
 
require __DIR__ . '/../vendor/autoload.php';
require_once '../includes/DbOperation.php';
 
$app = AppFactory::create();
 
$app->addRoutingMiddleware();
$app->addErrorMiddleware(true, true, true);

$default_path = '/proTeam/apis/public';
$full_path = 'https://localhost/proTeam';

//get all states
$app->get($default_path.'/getStates', function (Request $request, Response $response) {
    $db = new DbOperation();
    $result = $db->fetchStates();
    $response->getBody()->write(json_encode(array("state_list" => $result)));
    return $response;
});

//get all cities by states
$app->post($default_path.'/getCities', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('state_id'))) {
        $requestData = $request->getParsedBody();
        $state_id = $requestData['state_id'];
        $db = new DbOperation();
        $result = $db->fetchCities($state_id);
    $response->getBody()->write(json_encode(array("city_list" => $result)));
    return $response;
    }
});

$app->post($default_path.'/send_otp', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('ph_no'))) {
        $requestData = $request->getParsedBody();
        $ph_no = $requestData['ph_no'];
        
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->createOtp($ph_no);

        if ($result) {
            $responseData['error'] = false;
            $responseData['message'] = 'sent successfully';
            $responseData['otp_code'] = $db->getOTP($ph_no);
			$responseData['user'] = $db->isUserExist($ph_no);
			if($responseData['user'])
			{
				$responseData['user'] = $db->getUserById($responseData['user']);
			}
			
			
        } else
        {
            $responseData['error'] = true;
            $responseData['message'] = 'error in sending';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//registering a new user
$app->post($default_path.'/register', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('first_name', 'middle_name', 'last_name', 'ph_no', 'city_id'))) {
        $requestData = $request->getParsedBody();
        $first_name = $requestData['first_name'];
        $middle_name = $requestData['middle_name'];
        $last_name = $requestData['last_name'];
        $ph_no = $requestData['ph_no'];
        $email_id = $requestData['email_id'];
        $city_id = $requestData['city_id'];
		//$device_id = $requestData['device_id'];
		//$notify_key = $requestData['notify_key'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->registerUser($first_name, $middle_name, $last_name, $ph_no, $email_id, $city_id);

        if ($result == 'USER_EXIST') {
            $responseData['error'] = true;
            $responseData['message'] = 'This Mobile No. already exist, please login';
        } elseif (gettype($result)=='integer') {
            $responseData['error'] = false;
            $responseData['message'] = 'Registered successfully';
            $responseData['user'] = $db->getUserById($result);
        } else{
            $responseData['error'] = true;
            $responseData['message'] = 'Some error occurred';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

$app->post($default_path.'/QC_GPS', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('cid', 'current_latitude', 'current_longitude')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid']; // check if QC 
        $current_latitude = $requestData['current_latitude'];
        $current_longitude = $requestData['current_longitude'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->logQCLocation($cid, $current_latitude, $current_longitude);

        if ($result == 'NOT_QUARANTINE_CITIZEN') {
            $responseData['status'] = 501;
            $responseData['message'] = 'This is not Quarantine Citizen';
        } elseif ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Location logged successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while logging location';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

$app->post($default_path.'/uploadSelfie', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('cid')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid'];

        $selfie_src = upload_files();

        $db = new DbOperation();
        $result = $db->logQCSelfie($cid, $selfie_src);
        
        if ($result == 'NOT_QUARANTINE_CITIZEN') {
            $responseData['status'] = 501;
            $responseData['message'] = 'This is not Quarantine Citizen';
        } elseif ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Selfie logged successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while logging selfie';
        }
       
    }

    $response->getBody()->write(json_encode($responseData));
    return $response;

});


//function to check parameters
function isTheseParametersAvailable($required_fields)
{
    $error = false;
    $error_fields = "";
    $request_params = $_REQUEST;

    foreach ($required_fields as $field) {
        if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }

    if ($error) {
        $response = array();
        $response["error"] = true;
        $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        echo json_encode($response);
        return false;
    }
    return true;
}

function upload_files()
{

    $allowTypes = array('jpg','png','jpeg','gif');
    $uploadFolder="../../post_imgs/";

    $post_img_src = array();

    if(!empty($_FILES['selfie_img']['name']))
    {
        if(array_filter($_FILES['selfie_img']['name']))
        {
            $i=0;
            foreach($_FILES['selfie_img']['name'] as $key)
            {
                if($_FILES['selfie_img']['size'][$i] <=500000) //500KB
                {
                    
                    $fileNamemain = basename($_FILES['selfie_img']['name'][$i]);
                    $fileType = pathinfo($fileNamemain,PATHINFO_EXTENSION);
                    $newFileName = str_replace(" ","_", $fileNamemain);
                    
                    $j=0;
                    do{
                        // code to use value entered in image title by user as image name
                        $uploadPath = $uploadFolder . $newFileName . "_$j";
                        $uploadPath .=".".$fileType;
                        $j++;
                    }
                    while(file_exists($uploadPath)); // Check if file already exists
                    
                    if(in_array($fileType, $allowTypes)){
                        if(move_uploaded_file($_FILES["selfie_img"]["tmp_name"][$i], $uploadPath))
                        {
                            // echo "success";
                            $post_img_src[$i] = $uploadPath;
                        }
                        else
                        {
                            // echo "upload error";
                        }
                    }
                    else
                    {
                        // echo "file type";
                    }
                }
                else
                {
                    // echo "file size";
                }
                $i++;
            }
            
        }
        else
        {
            //echo "array filter";
        }
    }
    return $post_img_src;
}

$app->run();