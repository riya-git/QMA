<?php 

declare(strict_types=1);

date_default_timezone_set('Asia/Kolkata');
 
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
 
require __DIR__ . '/../vendor/autoload.php';
require_once '../includes/DbOperation.php';
 
$app = AppFactory::create();
 
$app->addRoutingMiddleware();
$app->addErrorMiddleware(true, true, true);

$default_path = '/proTeam/apis/public';
$full_path = 'https://localhost/proTeam';

//get all roles for web login
$app->get($default_path.'/getUserRoles', function (Request $request, Response $response) {
    
    $db = new DbOperation();
    $result = $db->fetchRoles();
    $response->getBody()->write(json_encode(array("role_list" => $result)));
    return $response;
});

// web login
$app->post($default_path.'/webLogin', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('login_type', 'user_name', 'pass_word')))
    {
        $requestData = $request->getParsedBody();
        $login_type = $requestData['login_type']; 
        $user_name = $requestData['user_name'];
        $pass_word = $requestData['pass_word'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->submitLogin($login_type, $user_name, $pass_word);

        if ($result == 'LOGIN_SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Logged In successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//get all states
$app->get($default_path.'/getStates', function (Request $request, Response $response) {
    
    $db = new DbOperation();
    $result = $db->fetchStates();
    $response->getBody()->write(json_encode(array("state_list" => $result)));
    return $response;
});

$app->post($default_path.'/stateDetails', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('state_id')))
    {
        $requestData = $request->getParsedBody();
        $state_id = $requestData['state_id'];
        
        $db = new DbOperation();
        $result = $db->fetchStates( $state_id);
        $response->getBody()->write(json_encode(array("state_list" => $result)));
        return $response;
    }
});

// insert new state
$app->post($default_path.'/state', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('mode', 'state_name')))
    {
        $requestData = $request->getParsedBody();
        $mode = $requestData['mode']; 
        $state_name = $requestData['state_name'];
        if($mode=='UPDATE')
        {
            $flg = isTheseParametersAvailable(array('state_id'));
            if($flg==false)
            {
                return $flg;
            }
            $state_id = $requestData['state_id'];
        }
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->submitState($state_id, $state_name, $mode);

        if ($result == 'ADD_SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'New State added successfully';
        } elseif ($result=='UPDATE_SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'State details updated successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//get all districts by state

$app->post($default_path.'/getDistrict', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('state_id')))
    {
        $requestData = $request->getParsedBody();
        $state_id = $requestData['state_id'];
        $district_id = $requestData['district_id'];
        
        $db = new DbOperation();
        $result = $db->fetchDistricts( $state_id, $district_id);
        $response->getBody()->write(json_encode(array("district_list" => $result)));
        return $response;
    }
});

// insert new/ update existing district
$app->post($default_path.'/district', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('mode', 'district_name', 'state_id')))
    {
        $requestData = $request->getParsedBody();
        $mode = $requestData['mode']; 
        $district_name = $requestData['district_name'];
        $state_id = $requestData['state_id'];
        if($mode=='UPDATE')
        {
            $flg = isTheseParametersAvailable(array('district_id'));
            if($flg==false)
            {
                return $flg;
            }
            $district_id = $requestData['district_id'];
        }
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->submitDistrict($district_id, $state_id, $district_name, $mode);

        if ($result == 'ADD_SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'New district added successfully';
        } elseif ($result=='UPDATE_SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'District details updated successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//get all cities by states
$app->post($default_path.'/getCities', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('state_id'))) {
        $requestData = $request->getParsedBody();
        $state_id = $requestData['state_id'];
        $db = new DbOperation();
        $result = $db->fetchCities($state_id);
    $response->getBody()->write(json_encode(array("city_list" => $result)));
    return $response;
    }
});

$app->post($default_path.'/send_otp', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('ph_no'))) {
        $requestData = $request->getParsedBody();
        $ph_no = $requestData['ph_no'];
        
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->createOtp($ph_no);

        if ($result) {
            $responseData['error'] = false;
            $responseData['message'] = 'sent successfully';
            $responseData['otp_code'] = $db->getOTP($ph_no);
			$responseData['user'] = $db->isUserExist($ph_no);
			if($responseData['user'])
			{
				$responseData['user'] = $db->getUserById($responseData['user']);
			}
			
			
        } else
        {
            $responseData['error'] = true;
            $responseData['message'] = 'error in sending';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//registering a new user
$app->post($default_path.'/register', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('first_name', 'middle_name', 'last_name', 'ph_no', 'city_id', 'case'))) {
        $requestData = $request->getParsedBody();
        $first_name = $requestData['first_name'];
        $middle_name = $requestData['middle_name'];
        $last_name = $requestData['last_name'];
        $ph_no = $requestData['ph_no'];
        $email_id = $requestData['email_id'];
        $city_id = $requestData['city_id'];
        $case = $requestData['case'];
		//$device_id = $requestData['device_id'];
        //$notify_key = $requestData['notify_key'];
        $reqtr_id = 0;
        $cid = 0;
        $req_details = 0;
        if($case=="CHKUP_REQUEST")
        {
            $flg = isTheseParametersAvailable(array('reqtr_id', 'req_details'));
            if($flg==false)
            {
                return $flg;
            }
            
            $reqtr_id = $requestData['reqtr_id'];
            $req_details = $requestData['req_details'];
        }
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->registerUser($first_name, $middle_name, $last_name, $ph_no, $email_id, $city_id, $case, $reqtr_id, $req_details);

        if ($case=="REGISTER" && $result == 'USER_EXIST') {
            $responseData['error'] = true;
            $responseData['message'] = 'This Mobile No. already exist, please login';
        } elseif ($case=="REGISTER" && gettype($result)=='integer') {
            $responseData['error'] = false;
            $responseData['message'] = 'Registered successfully';
            $responseData['user'] = $db->getUserById($result);
        } elseif ($case=="CHKUP_REQUEST" && gettype($result)=='integer') {
            $responseData['error'] = false;
            $responseData['message'] = 'Request Registered successfully';
            $responseData['user'] = $db->getUserById($result);
        } else{
            $responseData['error'] = true;
            $responseData['message'] = 'Some error occurred'.$result;
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

$app->post($default_path.'/updateNotiID', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('cid', 'noti_key')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid'];  
        $noti_key = $requestData['noti_key'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->updateNotiID($cid, $noti_key);

        if ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'ID updated successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while updating ID';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

$app->post($default_path.'/getUserByPhone', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('ph_no'))) {
        $requestData = $request->getParsedBody();
        $ph_no = $requestData['ph_no']; 
		
        $db = new DbOperation();
        $responseData = array();
        
        $responseData['user'] = $db->isUserExist($ph_no);
		if($responseData['user'])
		{
			$responseData['user'] = $db->getUserById($responseData['user']);
		}

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

$app->post($default_path.'/QC_GPS', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('cid', 'current_latitude', 'current_longitude')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid']; // check if QC 
        $current_latitude = $requestData['current_latitude'];
        $current_longitude = $requestData['current_longitude'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->logQCLocation($cid, $current_latitude, $current_longitude);

        if ($result == 'NOT_QUARANTINE_CITIZEN') {
            $responseData['status'] = 501;
            $responseData['message'] = 'This is not Quarantine Citizen';
        } elseif ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Location logged successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while logging location';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

$app->post($default_path.'/uploadSelfie', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('cid')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid'];

        $selfie_src = upload_files();

        $db = new DbOperation();
        $result = $db->logQCSelfie($cid, $selfie_src);
        
        if ($result == 'NOT_QUARANTINE_CITIZEN') {
            $responseData['status'] = 501;
            $responseData['message'] = 'This is not Quarantine Citizen';
        } elseif ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Selfie logged successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while logging selfie';
        }
       
    }

    $response->getBody()->write(json_encode($responseData));
    return $response;

});

$app->post($default_path.'/logBodyTemp', function (Request $request, Response $response, $args) {

   // if (isTheseParametersAvailable(array('body_temp')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid'];
        $body_temp = $requestData['body_temp'];
        $remarks = $requestData['remarks'];
        $emer_alert = $requestData['emer_alert'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->logQCBodyTemp($cid, $body_temp, $remarks, $emer_alert);

        if ($result == 'NOT_QUARANTINE_CITIZEN') {
            $responseData['status'] = 501;
            $responseData['message'] = 'This is not Quarantine Citizen';
        } elseif ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Body Temperature logged successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while logging Body Temperature';
        }

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//get all cases by states
$app->post($default_path.'/getCases', function (Request $request, Response $response) {
    // if (isTheseParametersAvailable(array('state_id'))) 
    {
        $requestData = $request->getParsedBody();
        $state_id = $requestData['state_id'];
        $db = new DbOperation();
        $result = $db->fetchCasesByState($state_id);
    $response->getBody()->write(json_encode(array("city_list" => $result)));
    return $response;
    }
});

$app->post($default_path.'/uploadTravelHist', function (Request $request, Response $response, $args) {

    if (isTheseParametersAvailable(array('cid', 'travel_datetime', 'travel_latitude', 'travel_longitude')))
    {
        $requestData = $request->getParsedBody();
        $cid = $requestData['cid']; // check if QC 
        $travel_datetime = $requestData['travel_datetime'];
        $travel_latitude = $requestData['travel_latitude'];
        $travel_longitude = $requestData['travel_longitude'];
		
        $db = new DbOperation();
        $responseData = array();

        $result = $db->logQCLocation($cid, $travel_latitude, $travel_longitude, 'TRAVEL_HISTORY', $travel_datetime);

        if ($result == 'NOT_QUARANTINE_CITIZEN') {
            $responseData['status'] = 501;
            $responseData['message'] = 'This is not Quarantine Citizen';
        } elseif ($result == 'NOT_REGISTERED_USER') {
            $responseData['status'] = 502;
            $responseData['message'] = 'This is not Registered User';
        } elseif ($result=='SUCCESS') {
            $responseData['status'] = 200;
            $responseData['message'] = 'Travel History logged successfully';
        } else{
            $responseData['status'] = 500;
            $responseData['message'] = 'Error while logging Travel History';
        }
        
        // print_r($requestData);

        $response->getBody()->write(json_encode($responseData));
        return $response;
    }
});

//get all locations of all confirmed cases
$app->post($default_path.'/getHeatMap', function (Request $request, Response $response) {
    // if (isTheseParametersAvailable(array('case', 'city_id'))) 
    {
        $requestData = $request->getParsedBody();
        $case = $requestData['case'];
        $city_id = $requestData['city_id'];
        $db = new DbOperation();
        $result = $db->fetchHeatMap($case, $city_id);
    $response->getBody()->write(json_encode(array("heatMap" => $result)));
    return $response;
    }
});


//function to check parameters
function isTheseParametersAvailable($required_fields)
{
    $error = false;
    $error_fields = "";
    $request_params = $_REQUEST;

    foreach ($required_fields as $field) {
        if ((gettype($request_params[$field]) != 'array' && (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0)) || (gettype($request_params[$field]) == 'array' && (!(array_filter($request_params[$field]))))) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }

    if ($error) {
        $response = array();
        $response["error"] = true;
        $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        echo json_encode($response);
        return false;
    }
    return true;
}

function upload_files()
{

    $allowTypes = array('jpg','png','jpeg','gif');
    $uploadFolder="../../post_imgs/";

    $post_img_src = array();

    if(!empty($_FILES['selfie_img']['name']))
    {
        if(array_filter($_FILES['selfie_img']['name']))
        {
            $i=0;
            // foreach($_FILES['selfie_img']['name'] as $key)
            {
                if($_FILES['selfie_img']['size'][$i] <=500000000) //500KB
                {
                    
                    $fileNamemain = basename($_FILES['selfie_img']['name'][$i]);
                    $fileType = pathinfo($fileNamemain,PATHINFO_EXTENSION);
                    $newFileName = str_replace(" ","_", $fileNamemain);
                    
                    $j=0;
                    do{
                        // code to use value entered in image title by user as image name
                        $uploadPath = $uploadFolder . $newFileName . "_$j";
                        $uploadPath .=".".$fileType;
                        $j++;
                    }
                    while(file_exists($uploadPath)); // Check if file already exists
                    
                    if(in_array($fileType, $allowTypes)){
                        if(move_uploaded_file($_FILES["selfie_img"]["tmp_name"][$i], $uploadPath))
                        {
                            // echo "success";
                            $post_img_src[$i] = $uploadPath;
                        }
                        else
                        {
                            // echo "upload error";
                        }
                    }
                    else
                    {
                        // echo "file type";
                    }
                }
                else
                {
                    // echo "file size";
                }
                // $i++;
            }
            
        }
        else
        {
            //echo "array filter";
        }
    }
    return $post_img_src[$i];
}

$app->run();