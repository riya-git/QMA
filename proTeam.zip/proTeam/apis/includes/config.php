<?php

// Live Settings
define('DB_USERNAME', 'id8578056_qma_user');
define('DB_PASSWORD', 'qma_user$#');
define('DB_HOST', 'localhost');
define('DB_NAME', 'id8578056_qma_db');


define('FIREBASE_API_KEY','');

?>