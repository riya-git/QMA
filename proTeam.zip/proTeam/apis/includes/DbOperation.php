<?php
 
class DbOperation
{
    //Variable to store database link
    private $con, $current_date, $current_time, $current_datetime;
 
    //Class constructor
    function __construct()
    {
        require_once dirname(__FILE__) . '/DbConnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();

        $this->current_date = date('Y-m-d');
        $this->current_time = date('H:i:s');
        $this->current_datetime = $this->current_date.' '.$this->current_time;
        $this->citizenSts_arr = array("N"=>"Normal Citizen", "TR"=>"Test Requested", "TP"=>"Test Pending", "TC"=>"Test Conducted", "Q"=>"Quarantined", "I"=>"Infected", "TN"=>"Negative", "R"=>"Recovered");
        $this->userRole_arr = array("SA"=>"Super Admin", "S"=>"State", "D"=>"District", "HC"=>"Health Center", "MO"=>"Medical Officer");
    }
    
    function fetchRoles()
    {
        return $this->userRole_arr;
    }
    
    function submitLogin($login_type, $user_name, $pass_word)
    {
        $qry = "select district_id, district_name from district_master where deleted=0 and state_id=?";
    }
    
    function fetchStates($state_id=0)
    {
        $qry = "select state_id, state_name from state_master where deleted=0";
        if($state_id!=0)
        {
            $qry .= " and state_id=?";
        }
        $stmt = $this->con->prepare($qry);
        if($state_id!=0)
        {
            $stmt->bind_param("i", $state_id);
        }
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($state_id, $state_name);

        $states = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp['state_id'] = $state_id;
            $temp['state_name'] = $state_name;

            array_push($states, $temp);
        }
        $stmt->close();
        return $states;
        
    }
    
    function submitState($state_id, $state_name, $mode)
    {
        if($mode=="ADD")
        {
            $stmt1 = $this->con->prepare("INSERT INTO state_master (state_name, deleted) VALUES (?, 0)");
            $stmt1->bind_param("s", $state_name);
            $stmt1->execute();
            $sid = mysqli_insert_id($this->con);
        }
        if($mode=="UPDATE")
        {
            $stmt1 = $this->con->prepare("UPDATE state_master SET state_name=? where state_id = ?");
            $stmt1->bind_param("si", $state_name, $state_id);
            $stmt1->execute();
            $sid = mysqli_affected_rows($this->con);
        }
        if($sid)
        {
            return $mode."_SUCCESS";
        }
        else{
            //echo $this->con->error;
            return false;
        }
    }
    
    function fetchDistricts($state_id, $district_id=0)
    {
        $qry = "select district_id, district_name from district_master where deleted=0 and state_id=?";
        if($district_id!=0)
        {
            $qry .= " and district_id=?";
        }
        $stmt = $this->con->prepare($qry);
        if($district_id!=0)
        {
            $stmt->bind_param("ii", $state_id, $district_id);
        }
        else
        {
            $stmt->bind_param("i", $state_id);
        }
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($district_id, $district_name);

        $district = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp['district_id'] = $district_id;
            $temp['district_name'] = $district_name;

            array_push($district, $temp);
        }
        $stmt->close();
        return $district;
        
    }
    
    function submitDistrict($district_id, $state_id, $district_name, $mode)
    {
        if($mode=="ADD")
        {
            $stmt1 = $this->con->prepare("INSERT INTO district_master (state_id, district_name, deleted) VALUES (?, ?, 0)");
            $stmt1->bind_param("is", $state_id, $district_name);
            $stmt1->execute();
            $did = mysqli_insert_id($this->con);
        }
        if($mode=="UPDATE")
        {
            $stmt1 = $this->con->prepare("UPDATE district_master SET district_name=? where district_id = ?");
            $stmt1->bind_param("si", $district_name, $district_id);
            $stmt1->execute();
            $did = mysqli_affected_rows($this->con);
        }
        if($did>0)
        {
            return $mode."_SUCCESS";
        }
        else{
            //echo $this->con->error;
            return false;
        }
    }
    
    function fetchCities($state_id)
    {
        $qry = "select city_id, city_name 
        from city_master C
        inner join district_master D
        on C.district_id=D.district_id
        where C.deleted=0 and D.deleted=0 and state_id=?";
        $stmt = $this->con->prepare($qry);
        $stmt->bind_param("i", $state_id);
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($city_id, $city_name);

        $cities = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp['city_id'] = $city_id;
            $temp['city_name'] = $city_name;

            array_push($cities, $temp);
        }
        $stmt->close();
        return $cities;
        
    }
    
	 //Method to get otp
     function getOTP($phno)
     {
         $stmt = $this->con->prepare("SELECT code FROM sms_codes WHERE mobno = ?");
         $stmt->bind_param("s", $phno);
         $stmt->execute();
         $stmt->bind_result($code);
         $stmt->fetch();
         $user = array();
         $user['code'] = $code;
         
         return $user;
     }
     
	  //Method to check if phno already exist
    function isUserExist($phno)
    {
        $stmt = $this->con->prepare("SELECT cid FROM citizens_details WHERE mobile_no = ?");
        $stmt->bind_param("s", $phno);
        $stmt->execute();
        $stmt->bind_result($cid);
        $stmt->fetch();
        $user = array();
        $user['cid'] = $cid;
         
        return $cid;
    }
    
	 //Method to get user by user id
    function getUserById($user_id)
    {
        global $citizenSts_arr;
		
        $stmt = $this->con->prepare("SELECT cid, first_name, middle_name, last_name, mobile_no,email_id,noti_key, status, city_id FROM citizens_details WHERE cid = ?");
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        $stmt->bind_result($cid, $first_name, $middle_name, $last_name, $ph_no,$email_id, $noti_key, $status, $city_id );
        $stmt->fetch();
        $user = array();
        $user['id'] = $cid;
        $user['name'] = $first_name;
        $user['last_name'] = $last_name;
        $user['phno'] = $ph_no;
		$user['email'] = $email_id;
        $user['noti_key'] = $noti_key;
		$user['Qstatus'] = ($status=="Q" || $status=="I") ? "Y" : "N";
		$user['status'] = $this->citizenSts_arr[$status];
        $user['city_id'] = $city_id;
        return $user;
    }
    
	public function createOtp($phno) {
        $otp = rand(1000, 9999);
        // delete the old otp if exists
        $stmt = $this->con->prepare("DELETE FROM sms_codes where mobno = ?");
        $stmt->bind_param("i", $phno);
        $stmt->execute();


        $stmt = $this->con->prepare("INSERT INTO sms_codes(mobno, code, status) values(?, ?, 0)");
        $stmt->bind_param("is", $phno, $otp);

        
        if ($stmt->execute())
        {
           /* $ch = curl_init();
            $user="ratnapriya0018@gmail.com:932121";
            $receipientno=$phno;
            $senderID="TEST SMS";
            $msgtxt="Your OTP for ProTeam CMA is ".$otp;
            curl_setopt($ch,CURLOPT_URL,  "http://api.mVaayoo.com/mvaayooapi/MessageCompose");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "user=$user&senderID=$senderID&receipientno=$receipientno&msgtxt=$msgtxt");
            $buffer = curl_exec($ch); */
            // if(empty ($buffer))
            { return true; }
            /* else
            { return false; } */
            /*curl_close($ch);*/
        }
        else{
            return false;
        }
    }

    //Method to create a new user
    function registerUser($first_name, $middle_name, $last_name, $ph_no, $email_id, $city_id, $case, $reqtr_id, $req_details)
    {
        $registered = $this->isUserExist($ph_no);
        $status = "N";
        if($case=="CHKUP_REQUEST")
        {
            $status = "TR";
            if($registered)
            {
                if($this->registerRequest($reqtr_id, $registered, $req_details))
                {
                    return $registered;
                }
                else{
                    return false;
                }
            }
        }

        if (!$registered) {
          $noti_key=$this->generateApiKey();
		  
            $stmt = $this->con->prepare("INSERT INTO citizens_details (first_name, middle_name, last_name,mobile_no,email_id, noti_key, status, city_id, qfrom_date, qperiod) VALUES (?, ?, ?, ?, ?,?, ?, ?, '0000-00-00', 0)");
            $stmt->bind_param("sssssssi", $first_name, $middle_name, $last_name, $ph_no, $email_id ,$noti_key, $status, $city_id);
			
            if ($stmt->execute())
            {
                $cid = mysqli_insert_id($this->con);
                if($case=="CHKUP_REQUEST")
                {
                    if($this->registerRequest($reqtr_id, $cid, $req_details))
                    {
                        return $cid;
                    }
                    else{
                        return false;
                    }
                }
                return $cid;
            }
            else
            {
                return $this->con->error;
            }
        }
        return 'USER_EXIST';
    }
    
	private function generateApiKey(){
        return md5(uniqid(rand(), true));
    }

    function registerRequest($reqtr_id, $cid, $req_details)
    {
        $stmt1 = $this->con->prepare("INSERT INTO chkup_request (req_datetime, reqtr_id, cid,req_details, deleted) VALUES (?, ?, ?, ?, 0)");
        $stmt1->bind_param("siis", $this->current_datetime, $reqtr_id, $cid, $req_details);
        if($stmt1->execute())
        {
            $devicetoken = getNotiID($cid);
            $res = array();
			$res['data']['title'] = 'Request for checkup raised successfully.';
			// $res['data']['message'] = '';

			 $fields = array(
						'registration_ids' => $devicetoken,
						'data' => $res,
					);

			 $this->sendGCM($fields);
            return true;
        }
        else{
            //echo $this->con->error;
            return false;
        }
    }
    
    function isQC($cid)
    {
        $stmt = $this->con->prepare("SELECT status FROM citizens_details WHERE cid = ?");
        $stmt->bind_param("i", $cid);
        $stmt->execute();
        $stmt->bind_result($status);
        $stmt->fetch();
        if($status=="Q" || $status=="I")
        {
            return 1; // Quarantined/ Confirmed
        }
        elseif($status=="")
        {
            return 2; // Not Registered
        }
        else{
            return false; // Registered but with status other than Quarantined/ Confirmed
        }
        
    }
    
    function updateNotiID($cid, $noti_key)
    {
        $flg = $this->isQC($cid);
        if($flg==2){
            return "NOT_REGISTERED_USER";
        }
        else{
            $stmt1 = $this->con->prepare("UPDATE citizens_details SET noti_key=? where cid = ?");
            $stmt1->bind_param("si", $noti_key, $cid);
            if($stmt1->execute())
            {
                return 'SUCCESS';
            }
            else
            {
                return false;
            }
        }
    }
    
    function getNotiID($cid)
    {
        $stmt = $this->con->prepare("SELECT noti_key FROM citizens_details WHERE cid = ?");
        $stmt->bind_param("i", $cid);
        $stmt->execute();
        $stmt->bind_result($noti_key);
        $stmt->fetch();
        return $noti_key;
        
    }
    
    function logQCLocation($cid, $current_latitude, $current_longitude, $case='QC_LOC', $travel_datetime = '')
    {
        $flg = $this->isQC($cid);
        if (!$flg) {
            return "NOT_QUARANTINE_CITIZEN";
        }
        elseif($flg==2){
            return "NOT_REGISTERED_USER";
        }
        else{
            //
            if($case=='QC_LOC')
            {
                $stmt = $this->con->prepare("INSERT INTO qc_travel_log (cid, log_datetime, current_latitude, current_longitude) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $cid, $this->current_datetime, $current_latitude, $current_longitude);
			
            if ($stmt->execute())
                return 'SUCCESS';
            else
                return false;
            }
            if($case=="TRAVEL_HISTORY")
            {
                $travel_datetime = array_filter($travel_datetime);
                $current_latitude = array_filter($current_latitude);
                $current_longitude = array_filter($current_longitude);
                if(count($travel_datetime)>0 && count($current_latitude)>0 && count($current_longitude)>0)
                {
                    $stmt1 = $this->con->prepare("INSERT INTO citizen_travel_history (`cid`, `travel_datetime`, `travel_latitude`, `travel_longitude`) VALUES (?,?,?,?)");
                    
                    foreach($travel_datetime as $key => $dt)
                    {
                        $stmt1->bind_param("isss", $cid, $dt, $current_latitude[$key], $current_longitude[$key]);
                        $res1[] = $stmt1->execute();
                    }
                }
                if(array_filter($res1))
                    return 'SUCCESS';
                else
                    return false;
            }
        }
        
    }

    //This method will log
    function logQCSelfie($cid, $selfie_src)
    {
       $flg = $this->isQC($cid);
        if (!$flg) {
            return "NOT_QUARANTINE_CITIZEN";
        }
        elseif($flg==2){
            return "NOT_REGISTERED_USER";
        }
        else {
            //
            $current_face_id = 'current_face_id';
             $stmt = $this->con->prepare("INSERT INTO qc_selfie_log (cid, log_datetime, current_selfie_src, current_face_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $cid, $this->current_datetime, $selfie_src, $current_face_id);
			
            if ($stmt->execute())
                return 'SUCCESS';
            else
                return false;
        }
        return "NOT_QUARANTINE_CITIZEN";
    }

    //This method will log
    function logQCBodyTemp($cid, $body_temp, $remarks, $emer_alert)
    {
       $flg = $this->isQC($cid);
        if (!$flg) {
            return "NOT_QUARANTINE_CITIZEN";
        }
        elseif($flg==2){
            return "NOT_REGISTERED_USER";
        }
        else {
            //
             $stmt = $this->con->prepare("INSERT INTO qc_bodytemp_log (cid, log_datetime, body_temp, remarks, emer_alert) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("isssi", $cid, $this->current_datetime, $body_temp, $remarks, $emer_alert);
			
            if ($stmt->execute())
                return 'SUCCESS';
            else
                return false;
        }
        return "NOT_QUARANTINE_CITIZEN";
    }
    
    function fetchCasesByState($state_id=0)
    {
        $qry = "select S.state_id as state_id, state_name, status, count(*) as case_cnt 
        from city_master C
        inner join district_master D
        on C.district_id=D.district_id
        inner join state_master S
        on S.state_id=D.state_id
        inner join citizens_details CD
        on C.city_id=CD.city_id
        where C.deleted=0 and D.deleted=0 and status in ('Q', 'I') ";
        if($state_id!=0)
        {
            $qry .= " and state_id=?";
        }
        $qry .= " group by status, S.state_id";
        $stmt = $this->con->prepare($qry);
        if($state_id!=0)
        {
            $stmt->bind_param("i", $state_id);
        }
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($state_id, $state_name, $status, $case_cnt);

        $cases = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp[$state_id]['state_name'] = $state_name;
            if($status=="Q")
            {
                $temp[$state_id]['quaratined'] = $case_cnt;
            }
            if($status=="I")
            {
                $temp[$state_id]['confirmed'] = $case_cnt;
            }

            array_push($cases, $temp);
        }
        $stmt->close();
        return $cases;
        
    }
    
    function fetchHeatMap($case, $city_id)
    {
        $qry = "select cid, ql_latitude, ql_longitude, city_id 
        from citizens_details 
        where status in ('Q', 'I') ";
        if($case=='Q' || $case=='I')
        {
            $qry .= " and status=?";
        }
        if($city_id!=0)
        {
            $qry .= " and city_id=?";
        }
        
        $stmt = $this->con->prepare($qry);
        if($case=='Q' || $case=='I')
        {
            $stmt->bind_param("s", $case);
        }
        if($city_id!=0)
        {
            $stmt->bind_param("i", $city_id);
        }
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($cid, $ql_latitude, $ql_longitude, $city_id);

        $heatmap = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp[$city_id]['cid'] = $cid;
            $temp[$city_id]['ql_latitude'] = $ql_latitude;
            $temp[$city_id]['ql_longitude'] = $ql_longitude;

            array_push($heatmap, $temp);
        }
        $stmt->close();
        return $heatmap;
        
    }
    
	
	function sendGCM($fields) {
         
       
        
        //firebase server url to send the curl request
        $url = 'https://fcm.googleapis.com/fcm/send';
 
        //building headers for the request
        $headers = array(
            'Authorization: key=' . FIREBASE_API_KEY,
            'Content-Type: application/json'
        );
 
        //Initializing curl to open a connection
        $ch = curl_init();
 
        //Setting the curl url
        curl_setopt($ch, CURLOPT_URL, $url);
        
        //setting the method as post
        curl_setopt($ch, CURLOPT_POST, true);
 
        //adding headers 
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
        //disabling ssl support
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        //adding the fields in json format 
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 
        //finally executing the curl request 
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
 
        //Now close the connection
        curl_close($ch);
 
        //and return the result 
        return $result;
    }
 
}