<?php
 
class DbOperation
{
    //Variable to store database link
    private $con, $current_date, $current_time, $current_datetime;
 
    //Class constructor
    function __construct()
    {
        require_once dirname(__FILE__) . '/DbConnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();

        $this->current_date = date('Y-m-d');
        $this->current_time = date('H:i:s');
        $this->current_datetime = $this->current_date.' '.$this->current_time;
        $this->citizenSts_arr = array("N"=>"Normal Citizen", "TP"=>"Test Pending", "TC"=>"Test Conducted", "Q"=>"Quarantined", "I"=>"Infected", "TN"=>"Negative", "R"=>"Recovered");
    }
    
    function fetchStates()
    {
        $qry = "select state_id, state_name from state_master where deleted=0";
        $stmt = $this->con->prepare($qry);
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($state_id, $state_name);

        $states = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp['state_id'] = $state_id;
            $temp['state_name'] = $state_name;

            array_push($states, $temp);
        }
        $stmt->close();
        return $states;
        
    }
    
    function fetchCities($state_id)
    {
        $qry = "select city_id, city_name 
        from city_master C
        inner join district_master D
        on C.district_id=D.district_id
        where C.deleted=0 and D.deleted=0 and state_id=?";
        $stmt = $this->con->prepare($qry);
        $stmt->bind_param("i", $state_id);
        $result = $stmt->execute();
        // var_dump($result);
        $stmt->bind_result($city_id, $city_name);

        $cities = array();
        while ($stmt->fetch())
        {
            $temp = array();
            
            $temp['city_id'] = $city_id;
            $temp['city_name'] = $city_name;

            array_push($cities, $temp);
        }
        $stmt->close();
        return $cities;
        
    }
    
	 //Method to get otp
     function getOTP($phno)
     {
         $stmt = $this->con->prepare("SELECT code FROM sms_codes WHERE mobno = ?");
         $stmt->bind_param("s", $phno);
         $stmt->execute();
         $stmt->bind_result($code);
         $stmt->fetch();
         $user = array();
         $user['code'] = $code;
         
         return $user;
     }
     
	  //Method to check if phno already exist
    function isUserExist($phno)
    {
        $stmt = $this->con->prepare("SELECT cid FROM citizens_details WHERE mobile_no = ?");
        $stmt->bind_param("s", $phno);
        $stmt->execute();
        $stmt->bind_result($cid);
        $stmt->fetch();
        $user = array();
        $user['cid'] = $cid;
         
        return $cid;
    }
    
	 //Method to get user by user id
    function getUserById($user_id)
    {
        global $citizenSts_arr;
		
        $stmt = $this->con->prepare("SELECT cid, first_name, middle_name, last_name, mobile_no,email_id,noti_key, status, city_id FROM citizens_details WHERE cid = ?");
        $stmt->bind_param("s", $user_id);
        $stmt->execute();
        $stmt->bind_result($cid, $first_name, $middle_name, $last_name, $ph_no,$email_id, $noti_key, $status, $city_id );
        $stmt->fetch();
        $user = array();
        $user['id'] = $user_id;
        $user['name'] = $first_name;
        $user['last_name'] = $last_name;
        $user['phno'] = $ph_no;
		$user['email'] = $email_id;
        $user['noti_key'] = $noti_key;
		$user['Qstatus'] = ($status=="Q" || $status=="I") ? "Y" : "N";
		$user['status'] = $this->citizenSts_arr[$status];
        $user['city_id'] = $city_id;
        return $user;
    }
    
	public function createOtp($phno) {
        $otp = rand(1000, 9999);
        // delete the old otp if exists
        $stmt = $this->con->prepare("DELETE FROM sms_codes where mobno = ?");
        $stmt->bind_param("i", $phno);
        $stmt->execute();


        $stmt = $this->con->prepare("INSERT INTO sms_codes(mobno, code, status) values(?, ?, 0)");
        $stmt->bind_param("is", $phno, $otp);

        
        if ($stmt->execute())
        {
            $ch = curl_init();
            $user="ratnapriya0018@gmail.com:932121";
            $receipientno=$phno;
            $senderID="TEST SMS";
            $msgtxt="Your OTP for ProTeam CMA is ".$otp;
            curl_setopt($ch,CURLOPT_URL,  "http://api.mVaayoo.com/mvaayooapi/MessageCompose");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "user=$user&senderID=$senderID&receipientno=$receipientno&msgtxt=$msgtxt");
            $buffer = curl_exec($ch);
            // if(empty ($buffer))
            { return true; }
            /* else
            { return false; } */
            curl_close($ch);
        }
        else{
            return false;
        }
    }

    //Method to create a new user
    function registerUser($first_name, $middle_name, $last_name, $ph_no, $email_id, $city_id)
    {
        if (!$this->isUserExist($ph_no)) {
          $noti_key=$this->generateApiKey();
		  
            $stmt = $this->con->prepare("INSERT INTO citizens_details (first_name, middle_name, last_name,mobile_no,email_id, noti_key, status, city_id, qfrom_date, qperiod) VALUES (?, ?, ?, ?, ?,?, 'N', ?, '0000-00-00', 0)");
            $stmt->bind_param("ssssssi", $first_name, $middle_name, $last_name, $ph_no, $email_id ,$noti_key, $city_id);
			
            if ($stmt->execute())
                return mysqli_insert_id($this->con);
                else
            return $this->con->error;
        }
        return 'USER_EXIST';
    }
    
	private function generateApiKey(){
        return md5(uniqid(rand(), true));
    }
    
    function isQC($cid)
    {
        $stmt = $this->con->prepare("SELECT status FROM citizens_details WHERE cid = ?");
        $stmt->bind_param("i", $cid);
        $stmt->execute();
        $stmt->bind_result($status);
        $stmt->fetch();
        if($status=="Q" || $status=="I")
        {
            return 1; // Quarantined/ Confirmed
        }
        elseif($status=="")
        {
            return 2; // Not Registered
        }
        else{
            return false; // Registered but with status other than Quarantined/ Confirmed
        }
        
    }
    
    function logQCLocation($cid, $current_latitude, $current_longitude)
    {
        $flg = $this->isQC($cid);
        if (!$flg) {
            return "NOT_QUARANTINE_CITIZEN";
        }
        elseif($flg==2){
            return "NOT_REGISTERED_USER";
        }
        else{
            //
             $stmt = $this->con->prepare("INSERT INTO qc_travel_log (cid, log_datetime, current_latitude, current_longitude) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $cid, $this->current_datetime, $current_latitude, $current_longitude);
			
            if ($stmt->execute())
                return 'SUCCESS';
            else
                return false;
        }
        
    }

    //This method will log
    function logQCSelfie($cid, $selfie_src)
    {
       $flg = $this->isQC($cid);
        if (!$flg) {
            return "NOT_QUARANTINE_CITIZEN";
        }
        elseif($flg==2){
            return "NOT_REGISTERED_USER";
        }
        else {
            //
            $current_face_id = 'current_face_id';
             $stmt = $this->con->prepare("INSERT INTO qc_selfie_log (cid, log_datetime, current_selfie_src, current_face_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $cid, $this->current_datetime, $selfie_src, $current_face_id);
			
            if ($stmt->execute())
                return 'SUCCESS';
            else
                return false;
        }
        return "NOT_QUARANTINE_CITIZEN";
    }
    
    // This method will get details of individual post requested
    function get_postbyid($post_id)
    {}

    function insert_post($post_details)
    {}

    function update_post($post_id, $post_details)
    {}
 
}